import sqlite3

def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL, description TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, name TEXT, email TEXT, message TEXT)")
    conn.commit()
    if not c.execute("SELECT COUNT(*) FROM products").fetchone()[0]:
        c.executemany("INSERT INTO products (name, price, description) VALUES (?, ?, ?)", [
            ("iPhone 14", 799.99, "Brand new Apple iPhone 14"),
            ("Samsung Galaxy S23", 699.99, "Latest Samsung flagship device"),
            ("OnePlus 12", 649.99, "Flagship killer from OnePlus")
        ])
    conn.commit()
    conn.close()

def get_products():
    with sqlite3.connect("database.db") as conn:
        return conn.execute("SELECT * FROM products").fetchall()

def get_product_by_id(pid):
    with sqlite3.connect("database.db") as conn:
        return conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()

def add_message(name, email, message):
    with sqlite3.connect("database.db") as conn:
        conn.execute("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)", (name, email, message))
        conn.commit()

def validate_admin(username, password):
    return username == "admin" and password == "password123"

def add_product(name, price, description):
    with sqlite3.connect("database.db") as conn:
        conn.execute("INSERT INTO products (name, price, description) VALUES (?, ?, ?)", (name, price, description))
        conn.commit()

def delete_product_by_id(pid):
    with sqlite3.connect("database.db") as conn:
        conn.execute("DELETE FROM products WHERE id=?", (pid,))
        conn.commit()

def update_product(pid, name, price, description):
    with sqlite3.connect("database.db") as conn:
        conn.execute("UPDATE products SET name=?, price=?, description=? WHERE id=?", (name, price, description, pid))
        conn.commit()
